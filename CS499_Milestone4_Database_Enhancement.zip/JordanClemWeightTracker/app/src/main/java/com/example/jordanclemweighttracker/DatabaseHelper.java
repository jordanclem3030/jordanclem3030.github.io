
package com.example.jordanclemweighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 3;

    private static final String TABLE_USERS = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";
    private static final String PASSWORD_SALT = "password_salt";

    private static final String TABLE_WEIGHTS = "weights";
    private static final String WEIGHT_ID = "id";
    private static final String WEIGHT_DATE = "date";
    private static final String WEIGHT_VALUE = "weight";
    private static final String WEIGHT_USER_ID = "user_id";

    private static final int HASH_ITERATIONS = 120000;
    private static final int HASH_LENGTH = 256;
    private static final int SALT_LENGTH = 16;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USERNAME + " TEXT UNIQUE NOT NULL, " +
                        PASSWORD + " TEXT NOT NULL, " +
                        PASSWORD_SALT + " TEXT NOT NULL)"
        );

        db.execSQL(
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        WEIGHT_DATE + " TEXT NOT NULL, " +
                        WEIGHT_VALUE + " REAL NOT NULL, " +
                        WEIGHT_USER_ID + " INTEGER, " +
                        "FOREIGN KEY(" + WEIGHT_USER_ID + ") REFERENCES " +
                        TABLE_USERS + "(" + USER_ID + "))"
        );

        db.execSQL(
                "CREATE INDEX idx_weights_user_id ON " +
                        TABLE_WEIGHTS + "(" + WEIGHT_USER_ID + ")"
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {

        // Version 1 to 2: Add ownership without deleting weights.
        if (oldVersion < 2) {
            db.execSQL(
                    "ALTER TABLE " + TABLE_WEIGHTS +
                            " ADD COLUMN " + WEIGHT_USER_ID + " INTEGER"
            );
        }

        // Version 2 to 3: Add a salt column.
        if (oldVersion < 3) {
            db.execSQL(
                    "ALTER TABLE " + TABLE_USERS +
                            " ADD COLUMN " + PASSWORD_SALT + " TEXT"
            );

            // Convert existing plaintext passwords to hashes.
            try (Cursor cursor = db.query(
                    TABLE_USERS,
                    new String[]{USER_ID, PASSWORD},
                    null, null, null, null, null
            )) {
                while (cursor.moveToNext()) {

                    int id = cursor.getInt(0);
                    String oldPassword = cursor.getString(1);

                    String salt = generateSalt();
                    String hash = hashPassword(oldPassword, salt);

                    ContentValues values = new ContentValues();
                    values.put(PASSWORD, hash);
                    values.put(PASSWORD_SALT, salt);

                    db.update(
                            TABLE_USERS,
                            values,
                            USER_ID + "=?",
                            new String[]{String.valueOf(id)}
                    );
                }
            }

            db.execSQL(
                    "CREATE INDEX IF NOT EXISTS idx_weights_user_id ON " +
                            TABLE_WEIGHTS + "(" + WEIGHT_USER_ID + ")"
            );

            // Associate old weights only if there is one account.
            int onlyUserId = -1;
            int userCount = 0;

            try (Cursor users = db.query(
                    TABLE_USERS,
                    new String[]{USER_ID},
                    null, null, null, null, null
            )) {
                while (users.moveToNext()) {
                    userCount++;
                    onlyUserId = users.getInt(0);

                    if (userCount > 1) {
                        break;
                    }
                }
            }

            if (userCount == 1) {
                ContentValues values = new ContentValues();
                values.put(WEIGHT_USER_ID, onlyUserId);

                db.update(
                        TABLE_WEIGHTS,
                        values,
                        WEIGHT_USER_ID + " IS NULL",
                        null
                );
            }
        }
    }

    private String generateSalt() {
        byte[] salt = new byte[SALT_LENGTH];
        new SecureRandom().nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    private String hashPassword(String password, String salt) {
        PBEKeySpec spec = null;

        try {
            byte[] saltBytes = Base64.decode(salt, Base64.NO_WRAP);

            spec = new PBEKeySpec(
                    password.toCharArray(),
                    saltBytes,
                    HASH_ITERATIONS,
                    HASH_LENGTH
            );

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return Base64.encodeToString(hash, Base64.NO_WRAP);

        } catch (Exception exception) {
            throw new IllegalStateException(
                    "Password hashing failed.",
                    exception
            );
        } finally {
            if (spec != null) {
                spec.clearPassword();
            }
        }
    }

    // ---------------- USER ACCOUNTS ----------------

    public boolean addUser(String username, String password) {

        if (username == null || username.trim().isEmpty()
                || password == null || password.isEmpty()) {
            return false;
        }

        String salt = generateSalt();
        String hash = hashPassword(password, salt);

        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, hash);
        values.put(PASSWORD_SALT, salt);

        return getWritableDatabase().insert(
                TABLE_USERS, null, values
        ) != -1;
    }

    public boolean checkUser(String username, String password) {

        if (username == null || password == null) {
            return false;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{PASSWORD, PASSWORD_SALT},
                USERNAME + "=?",
                new String[]{username},
                null, null, null
        )) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            String savedHash = cursor.getString(0);
            String salt = cursor.getString(1);

            if (savedHash == null || salt == null) {
                return false;
            }

            String enteredHash = hashPassword(password, salt);

            byte[] expected = Base64.decode(
                    savedHash, Base64.NO_WRAP
            );

            byte[] actual = Base64.decode(
                    enteredHash, Base64.NO_WRAP
            );

            return MessageDigest.isEqual(expected, actual);
        }
    }

    public int getUserId(String username) {

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{USER_ID},
                USERNAME + "=?",
                new String[]{username},
                null, null, null
        )) {

            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        }

        return -1;
    }

    // ---------------- WEIGHT RECORDS ----------------

    public boolean addWeightForUser(
            int userId,
            String date,
            double weight
    ) {

        if (userId <= 0 || date == null || date.trim().isEmpty()
                || Double.isNaN(weight)
                || Double.isInfinite(weight)
                || weight <= 0 || weight > 1000) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(WEIGHT_USER_ID, userId);
        values.put(WEIGHT_DATE, date);
        values.put(WEIGHT_VALUE, weight);

        return getWritableDatabase().insert(
                TABLE_WEIGHTS, null, values
        ) != -1;
    }

    public Cursor getWeightsForUser(int userId) {

        return getReadableDatabase().query(
                TABLE_WEIGHTS,
                null,
                WEIGHT_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null,
                WEIGHT_ID + " ASC"
        );
    }

    public boolean updateWeightForUser(
            int id,
            int userId,
            String date,
            double weight
    ) {

        if (id <= 0 || userId <= 0
                || date == null || date.trim().isEmpty()
                || Double.isNaN(weight)
                || Double.isInfinite(weight)
                || weight <= 0 || weight > 1000) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(WEIGHT_DATE, date);
        values.put(WEIGHT_VALUE, weight);

        int updated = getWritableDatabase().update(
                TABLE_WEIGHTS,
                values,
                WEIGHT_ID + "=? AND " + WEIGHT_USER_ID + "=?",
                new String[]{
                        String.valueOf(id),
                        String.valueOf(userId)
                }
        );

        return updated > 0;
    }

    public boolean deleteWeightForUser(int id, int userId) {

        if (id <= 0 || userId <= 0) {
            return false;
        }

        int deleted = getWritableDatabase().delete(
                TABLE_WEIGHTS,
                WEIGHT_ID + "=? AND " + WEIGHT_USER_ID + "=?",
                new String[]{
                        String.valueOf(id),
                        String.valueOf(userId)
                }
        );

        return deleted > 0;
    }
}
