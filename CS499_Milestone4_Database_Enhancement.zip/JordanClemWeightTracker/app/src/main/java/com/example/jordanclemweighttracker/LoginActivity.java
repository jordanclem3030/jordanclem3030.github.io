
package com.example.jordanclemweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Connect Java variables to the login screen.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount =
                findViewById(R.id.buttonCreateAccount);

        // Open the persistent SQLite database.
        databaseHelper = new DatabaseHelper(this);

        buttonLogin.setOnClickListener(view -> loginUser());
        buttonCreateAccount.setOnClickListener(
                view -> createAccount()
        );
    }

    // ---------------- LOGIN ----------------

    private void loginUser() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        // Both fields are required.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Check credentials against the SQLite database.
        if (databaseHelper.checkUser(username, password)) {

            // Retrieve the authenticated user's database ID.
            int userId = databaseHelper.getUserId(username);

            if (userId <= 0) {
                Toast.makeText(
                        this,
                        "Unable to identify the user account.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            Toast.makeText(
                    this,
                    "Login successful!",
                    Toast.LENGTH_SHORT
            ).show();

            // Pass the logged-in user's ID to the SMS screen.
            Intent intent = new Intent(
                    LoginActivity.this,
                    SmsActivity.class
            );

            intent.putExtra("USER_ID", userId);

            startActivity(intent);
            finish();

        } else {

            Toast.makeText(
                    this,
                    "Invalid username or password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // ---------------- CREATE ACCOUNT ----------------

    private void createAccount() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        // Validate the registration fields.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Enter a username and password to create an account.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Save the account through DatabaseHelper.
        boolean accountCreated =
                databaseHelper.addUser(username, password);

        if (accountCreated) {

            Toast.makeText(
                    this,
                    "Account created successfully! You can now log in.",
                    Toast.LENGTH_LONG
            ).show();

            // Clear the password after account creation.
            editPassword.setText("");

        } else {

            Toast.makeText(
                    this,
                    "Account could not be created. Username may already exist.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
