
package com.example.jordanclemweighttracker;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.Locale;

public class WeightActivity extends AppCompatActivity {

    private static final double GOAL_WEIGHT = 155.0;

    private EditText editDate;
    private EditText editWeight;
    private Button buttonUpdateWeight;
    private LinearLayout weightContainer;

    private TextView textCurrentWeight;
    private TextView textGoalWeight;
    private TextView textPoundsRemaining;

    private DatabaseHelper databaseHelper;

    // ID of the authenticated user.
    private int userId = -1;

    // ID of the weight record selected for editing.
    private int selectedWeightId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Receive the user ID from SmsActivity.
        userId = getIntent().getIntExtra("USER_ID", -1);

        if (userId <= 0) {
            Toast.makeText(
                    this,
                    "Please log in to continue.",
                    Toast.LENGTH_SHORT
            ).show();

            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_weight);

        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);

        Button buttonAddWeight =
                findViewById(R.id.buttonAddWeight);

        buttonUpdateWeight =
                findViewById(R.id.buttonUpdateWeight);

        weightContainer =
                findViewById(R.id.weightContainer);

        textCurrentWeight =
                findViewById(R.id.textCurrentWeight);

        textGoalWeight =
                findViewById(R.id.textGoalWeight);

        textPoundsRemaining =
                findViewById(R.id.textPoundsRemaining);

        textGoalWeight.setText(
                "Goal Weight: " + GOAL_WEIGHT + " lbs"
        );

        databaseHelper = new DatabaseHelper(this);

        buttonUpdateWeight.setEnabled(false);

        // Load only this user's weight records.
        displayWeights();

        buttonAddWeight.setOnClickListener(
                view -> addWeight()
        );

        buttonUpdateWeight.setOnClickListener(
                view -> updateWeight()
        );
    }

    // CREATE: Add a weight record for the logged-in user.
    private void addWeight() {

        String date =
                editDate.getText().toString().trim();

        String weightText =
                editWeight.getText().toString().trim();

        if (date.isEmpty() || weightText.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a date and weight.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        try {
            double weight = Double.parseDouble(weightText);

            if (Double.isNaN(weight)
                    || Double.isInfinite(weight)
                    || weight <= 0
                    || weight > 1000) {

                Toast.makeText(
                        this,
                        "Please enter a weight between 1 and 1000 lbs.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            boolean inserted =
                    databaseHelper.addWeightForUser(
                            userId,
                            date,
                            weight
                    );

            if (inserted) {

                Toast.makeText(
                        this,
                        "Weight added successfully.",
                        Toast.LENGTH_SHORT
                ).show();

                if (weight <= GOAL_WEIGHT) {
                    sendGoalSms();
                }

                clearFields();
                displayWeights();

            } else {

                Toast.makeText(
                        this,
                        "Unable to add weight.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException exception) {

            Toast.makeText(
                    this,
                    "Please enter a valid weight.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // READ: Retrieve only the logged-in user's records.
    private void displayWeights() {

        weightContainer.removeAllViews();

        try (Cursor cursor =
                     databaseHelper.getWeightsForUser(userId)) {

            if (cursor.getCount() == 0) {

                TextView emptyMessage = new TextView(this);
                emptyMessage.setText("No weight records yet.");
                emptyMessage.setPadding(8, 16, 8, 16);

                weightContainer.addView(emptyMessage);

                textCurrentWeight.setText(
                        "Current Weight: No data"
                );

                textPoundsRemaining.setText(
                        "Pounds Remaining: No data"
                );

                return;
            }

            double currentWeight = 0;

            while (cursor.moveToNext()) {

                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow("id")
                );

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("date")
                );

                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight")
                );

                currentWeight = weight;

                createWeightRow(id, date, weight);
            }

            updateProgressDisplay(currentWeight);
        }
    }

    // Calculate progress toward the weight goal.
    private void updateProgressDisplay(double currentWeight) {

        textCurrentWeight.setText(
                "Current Weight: " + currentWeight + " lbs"
        );

        double poundsRemaining =
                currentWeight - GOAL_WEIGHT;

        if (poundsRemaining > 0) {

            textPoundsRemaining.setText(
                    "Pounds Remaining: "
                            + String.format(
                            Locale.US,
                            "%.1f",
                            poundsRemaining
                    )
                            + " lbs"
            );

        } else if (poundsRemaining == 0) {

            textPoundsRemaining.setText("Goal reached!");

        } else {

            textPoundsRemaining.setText(
                    "Goal exceeded by "
                            + String.format(
                            Locale.US,
                            "%.1f",
                            Math.abs(poundsRemaining)
                    )
                            + " lbs!"
            );
        }
    }

    // Display one weight record with Edit and Delete buttons.
    private void createWeightRow(
            int id,
            String date,
            double weight
    ) {

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(
                android.view.Gravity.CENTER_VERTICAL
        );
        row.setPadding(8, 8, 8, 8);

        TextView dateView = new TextView(this);
        dateView.setText(date);
        dateView.setLayoutParams(
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                )
        );

        TextView weightView = new TextView(this);
        weightView.setText(weight + " lbs");
        weightView.setLayoutParams(
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                )
        );

        Button editButton = new Button(this);
        editButton.setText("Edit");

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");

        editButton.setOnClickListener(view -> {

            selectedWeightId = id;

            editDate.setText(date);
            editWeight.setText(String.valueOf(weight));

            buttonUpdateWeight.setEnabled(true);

            Toast.makeText(
                    this,
                    "Edit the values above, then press Update.",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // DELETE: Only delete a record owned by this user.
        deleteButton.setOnClickListener(view -> {

            boolean deleted =
                    databaseHelper.deleteWeightForUser(
                            id,
                            userId
                    );

            if (deleted) {

                Toast.makeText(
                        this,
                        "Weight deleted.",
                        Toast.LENGTH_SHORT
                ).show();

                if (selectedWeightId == id) {
                    clearFields();
                }

                displayWeights();

            } else {

                Toast.makeText(
                        this,
                        "Unable to delete weight.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        row.addView(dateView);
        row.addView(weightView);
        row.addView(editButton);
        row.addView(deleteButton);

        weightContainer.addView(row);
    }

    // UPDATE: Modify only a record owned by this user.
    private void updateWeight() {

        if (selectedWeightId == -1) {

            Toast.makeText(
                    this,
                    "Select a weight record to edit first.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        String date =
                editDate.getText().toString().trim();

        String weightText =
                editWeight.getText().toString().trim();

        if (date.isEmpty() || weightText.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter a date and weight.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        try {

            double weight = Double.parseDouble(weightText);

            if (Double.isNaN(weight)
                    || Double.isInfinite(weight)
                    || weight <= 0
                    || weight > 1000) {

                Toast.makeText(
                        this,
                        "Please enter a weight between 1 and 1000 lbs.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            boolean updated =
                    databaseHelper.updateWeightForUser(
                            selectedWeightId,
                            userId,
                            date,
                            weight
                    );

            if (updated) {

                Toast.makeText(
                        this,
                        "Weight updated successfully.",
                        Toast.LENGTH_SHORT
                ).show();

                clearFields();
                displayWeights();

            } else {

                Toast.makeText(
                        this,
                        "Unable to update weight.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException exception) {

            Toast.makeText(
                    this,
                    "Please enter a valid weight.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Send an optional SMS notification when the goal is reached.
    private void sendGoalSms() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        SharedPreferences preferences =
                getSharedPreferences(
                        "WeightTrackerPreferences",
                        Context.MODE_PRIVATE
                );

        String phoneNumber =
                preferences.getString("phoneNumber", "");

        if (phoneNumber.isEmpty()) {
            return;
        }

        try {

            SmsManager smsManager =
                    SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "Congratulations! You reached your Weight Tracker goal of 155 lbs!",
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Goal SMS notification sent!",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception exception) {

            Toast.makeText(
                    this,
                    "Unable to send SMS notification.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Clear input fields after adding, editing, or deleting.
    private void clearFields() {

        editDate.setText("");
        editWeight.setText("");

        selectedWeightId = -1;
        buttonUpdateWeight.setEnabled(false);
    }
}
