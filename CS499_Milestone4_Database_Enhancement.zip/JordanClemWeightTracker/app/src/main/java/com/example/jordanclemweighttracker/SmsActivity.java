
package com.example.jordanclemweighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private ActivityResultLauncher<String> smsPermissionLauncher;
    private EditText editPhoneNumber;
    private SharedPreferences preferences;

    // Database ID of the logged-in user.
    private int userId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Retrieve the ID passed from LoginActivity.
        userId = getIntent().getIntExtra("USER_ID", -1);

        // Prevent access without a valid user ID.
        if (userId <= 0) {
            Toast.makeText(
                    this,
                    "Please log in to continue.",
                    Toast.LENGTH_SHORT
            ).show();

            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_sms);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);

        preferences = getSharedPreferences(
                "WeightTrackerPreferences",
                MODE_PRIVATE
        );

        Button buttonEnableSms = findViewById(R.id.buttonEnableSms);
        Button buttonNotNow = findViewById(R.id.buttonNotNow);

        // Handle the SMS permission response.
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {

                    if (isGranted) {
                        Toast.makeText(
                                this,
                                "SMS notifications enabled.",
                                Toast.LENGTH_SHORT
                        ).show();
                    } else {
                        Toast.makeText(
                                this,
                                "SMS permission denied. Weight Tracker will still work normally.",
                                Toast.LENGTH_LONG
                        ).show();
                    }

                    openWeightTracker();
                }
        );

        buttonEnableSms.setOnClickListener(view -> {

            String phoneNumber =
                    editPhoneNumber.getText().toString().trim();

            if (phoneNumber.isEmpty()) {
                Toast.makeText(
                        this,
                        "Please enter a phone number.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            // Save the phone number for optional notifications.
            preferences.edit()
                    .putString("phoneNumber", phoneNumber)
                    .apply();

            requestSmsPermission();
        });

        buttonNotNow.setOnClickListener(view -> {
            Toast.makeText(
                    this,
                    "SMS notifications skipped.",
                    Toast.LENGTH_SHORT
            ).show();

            openWeightTracker();
        });
    }

    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "SMS notifications are already enabled.",
                    Toast.LENGTH_SHORT
            ).show();

            openWeightTracker();

        } else {
            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }

    private void openWeightTracker() {

        // Pass the same user ID to WeightActivity.
        Intent intent = new Intent(
                SmsActivity.this,
                WeightActivity.class
        );

        intent.putExtra("USER_ID", userId);

        startActivity(intent);
        finish();
    }
}
