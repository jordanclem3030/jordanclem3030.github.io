"""
CS 499 Milestone Three - Enhancement Two: Algorithms and Data Structures
Artifact: CS 370 Treasure Hunt Intelligent Agent
Student: Jordan Clem

Enhancement focus:
- Configurable deep-Q training parameters
- Epsilon-greedy action selection restricted to valid actions
- Bounded experience replay configuration
- Separate target network with periodic synchronization
- Win-rate, loss, episode-step, and elapsed-time performance tracking
- Safety cutoff during evaluation
- Completion testing from all valid starting cells

This module contains the enhanced algorithmic portions of the Treasure Hunt
artifact. It is intended to be used with the original TreasureMaze.py and
GameExperience.py support classes from the CS 370 project.
"""

from __future__ import print_function
import datetime
import random
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import clone_model

from TreasureMaze import TreasureMaze
from GameExperience import GameExperience

LEFT = 0
UP = 1
RIGHT = 2
DOWN = 3

actions_dict = {
    LEFT: "left",
    UP: "up",
    RIGHT: "right",
    DOWN: "down",
}

epsilon_min = 0.05
epsilon_decay = 0.995

loss_fn = tf.keras.losses.MeanSquaredError()
optimizer = tf.keras.optimizers.Adam()


def format_time(seconds):
    """Return elapsed time in an easy-to-read format."""
    if seconds < 400:
        return "%.1f seconds" % float(seconds)
    if seconds < 4000:
        return "%.2f minutes" % (seconds / 60.0)
    return "%.2f hours" % (seconds / 3600.0)


def play_game(model, qmaze, pirate_cell, max_steps=None):
    """Evaluate a trained policy with a finite step limit."""
    qmaze.reset(pirate_cell)
    envstate = qmaze.observe()
    steps = 0

    if max_steps is None:
        max_steps = qmaze.maze.size * 4

    while steps < max_steps:
        state = np.asarray(envstate, dtype=np.float32)
        if state.ndim == 1:
            state = np.expand_dims(state, axis=0)

        q_values = model(state, training=False).numpy()
        valid_actions = qmaze.valid_actions()

        if not valid_actions:
            return False

        # Choose the highest-valued action that is actually legal.
        action = max(valid_actions, key=lambda a: q_values[0][a])
        envstate, _, game_status = qmaze.act(action)
        steps += 1

        if game_status == "win":
            return True
        if game_status == "lose":
            return False

    return False


def completion_check(model, maze_or_qmaze, max_steps=None):
    """Require the learned policy to succeed from every playable start cell."""
    if isinstance(maze_or_qmaze, TreasureMaze):
        qmaze = maze_or_qmaze
    else:
        qmaze = TreasureMaze(maze_or_qmaze)

    for cell in qmaze.free_cells:
        if not qmaze.valid_actions(cell):
            continue
        if not play_game(model, qmaze, cell, max_steps=max_steps):
            return False
    return True


@tf.function
def train_step(model, x, y):
    """Perform one gradient update and return the batch loss."""
    with tf.GradientTape() as tape:
        q_values = model(x, training=True)
        loss = loss_fn(y, q_values)

    grads = tape.gradient(loss, model.trainable_variables)
    optimizer.apply_gradients(zip(grads, model.trainable_variables))
    return loss


def qtrain(model, maze, **opt):
    """
    Train the pirate agent with enhanced deep Q-learning.

    The configurable options make algorithmic trade-offs explicit instead of
    hiding them as hard-coded values.
    """
    n_epoch = opt.get("n_epoch", 15000)
    max_memory = opt.get("max_memory", 1000)
    data_size = opt.get("data_size", 50)
    target_update_freq = opt.get("target_update_freq", 50)
    epsilon = opt.get("epsilon", 1.0)

    start_time = datetime.datetime.now()
    qmaze = TreasureMaze(maze)

    # A target network improves learning stability by preventing the target
    # values from changing on every online-network update.
    target_model = clone_model(model)
    target_model.set_weights(model.get_weights())

    # GameExperience enforces the configured replay-memory capacity.
    experience = GameExperience(
        model,
        target_model,
        max_memory=max_memory
    )

    win_history = []
    metrics = []
    history_size = max(1, qmaze.maze.size // 2)
    total_steps = 0

    for epoch in range(n_epoch):
        pirate_start = random.choice(qmaze.free_cells)
        qmaze.reset(pirate_start)
        envstate = qmaze.observe()

        game_over = False
        episode_steps = 0
        total_loss = 0.0
        result = "incomplete"

        while not game_over:
            previous_envstate = envstate
            valid_actions = qmaze.valid_actions()

            if not valid_actions:
                win_history.append(0)
                result = "trapped"
                break

            # Epsilon-greedy decision strategy balances exploration/exploitation.
            if np.random.random() < epsilon:
                action = random.choice(valid_actions)
            else:
                q_values = np.asarray(
                    experience.predict(previous_envstate)
                ).reshape(-1)
                action = max(valid_actions, key=lambda a: q_values[a])

            envstate, reward, game_status = qmaze.act(action)
            game_over = game_status in ("win", "lose")

            if game_over:
                result = game_status
                win_history.append(1 if game_status == "win" else 0)

            # Structured transition used by experience replay:
            # [state, action, reward, next_state, terminal]
            episode = [
                previous_envstate,
                action,
                reward,
                envstate,
                game_over,
            ]
            experience.remember(episode)

            inputs, targets = experience.get_data(data_size)
            inputs = tf.convert_to_tensor(inputs, dtype=tf.float32)
            targets = tf.convert_to_tensor(targets, dtype=tf.float32)

            batch_loss = train_step(model, inputs, targets)
            total_loss += float(batch_loss.numpy())

            episode_steps += 1
            total_steps += 1

            if total_steps % target_update_freq == 0:
                target_model.set_weights(model.get_weights())

        recent = win_history[-history_size:]
        win_rate = sum(recent) / len(recent) if recent else 0.0
        average_loss = total_loss / max(episode_steps, 1)
        elapsed_seconds = (datetime.datetime.now() - start_time).total_seconds()

        metrics.append({
            "epoch": epoch,
            "result": result,
            "episode_steps": episode_steps,
            "average_loss": average_loss,
            "win_rate": win_rate,
            "epsilon": epsilon,
            "elapsed_seconds": elapsed_seconds,
        })

        # Decay exploration gradually, while retaining a minimum exploration rate.
        if win_rate > 0.90:
            epsilon = epsilon_min
        else:
            epsilon = max(epsilon * epsilon_decay, epsilon_min)

        print(
            "Epoch: {:03d}/{:d} | Loss: {:.4f} | Steps: {:d} | "
            "Win rate: {:.3f} | Epsilon: {:.3f} | time: {}".format(
                epoch,
                n_epoch - 1,
                average_loss,
                episode_steps,
                win_rate,
                epsilon,
                format_time(elapsed_seconds),
            )
        )

        # A recent 100% rate alone is not enough. Verify all valid start cells.
        if win_rate >= 0.999 and completion_check(model, qmaze):
            print("Validated solution at epoch {}".format(epoch))
            break

    total_time = (datetime.datetime.now() - start_time).total_seconds()
    print("Training complete in:", format_time(total_time))

    # Returning metrics makes the enhancement measurable and supports later
    # comparison of training settings and algorithmic trade-offs.
    return metrics
